#include<stdio.h>
#include<string.h>
#include<stdlib.h>

const int cust_name_len = 55;

struct customer{
	char name[cust_name_len];
	char membershipName[20];
	
	struct customer *left, *right;
} *rootCustomer = 0;

struct membership{
	char name[20];
	
	struct membership *left, *right;
} *rootMembership = 0;

struct membership *newMembership(char name[]){
	struct membership *temp = (struct membership*)malloc(sizeof(struct membership));
	temp->left = temp->right = 0;
	strcpy(temp->name, name);
	
	return temp;
}

struct customer *newCustomer(char name[], char membershipName[]){
	struct customer *temp = (struct customer*)malloc(sizeof(struct customer));
	temp->left = temp->right = 0;
	strcpy(temp->name, name);
	strcpy(temp->membershipName, membershipName);
	return temp;
}

void insertMembership(struct membership *curr, char name[]){
	if(rootMembership == 0){
		rootMembership = newMembership(name);
	}
	else{
		if(strcmp(name, curr->name) < 0 && curr->left == 0){
			curr->left = newMembership(name);
		}
		else if(strcmp(name, curr->name) > 0 && curr->right == 0){
			curr->right = newMembership(name);
		}
		else if(strcmp(name, curr->name) < 0 ){
			insertMembership(curr->left, name);
		}
		else if(strcmp(name, curr->name) > 0 ){
			insertMembership(curr->right, name);
		}
	}
}

void insertCustomer(struct customer *curr, char name[], char membershipName[]){
	if(rootCustomer == 0){
		rootCustomer = newCustomer(name, membershipName);
	}
	else{
		if(strcmpi(name, curr->name) == 0){
			strcpy(curr->membershipName, membershipName);
			printf("Customer already exists! Updated membership.\n");
			getchar();
		}
		if(strcmpi(name, curr->name) < 0 && curr->left == 0){
			curr->left = newCustomer(name, membershipName);
		}
		else if(strcmpi(name, curr->name) > 0 && curr->right == 0){
			curr->right = newCustomer(name, membershipName);
		}
		else if(strcmpi(name, curr->name) < 0 ){
			insertCustomer(curr->left, name, membershipName);
		}
		else if(strcmpi(name, curr->name) > 0 ){
			insertCustomer(curr->right, name, membershipName);
		}
	}
}

void viewMembership(struct membership *curr){
	if(curr != 0){
		viewMembership(curr->left);
		printf("%s ", curr->name);
		viewMembership(curr->right);
	}
}

void viewCustomer(struct customer *curr){
	if(curr != 0){
		viewCustomer(curr->left);
		printf("%s %s\n", curr->name, curr->membershipName);
		viewCustomer(curr->right);
	}
}

//this time we use void. small difference than we last learned
void delRecursive(struct customer *parentNodeToDel, struct customer *nodeToDel){
	if(nodeToDel->left == 0 && nodeToDel->right == 0){
		if(strcmpi(nodeToDel->name, parentNodeToDel->name) < 0){
			parentNodeToDel->left = 0;
		}
		else{
			parentNodeToDel->right = 0;
		}
		free(nodeToDel);
	}
	else if(nodeToDel->left != 0 && nodeToDel->right == 0){
		if(strcmpi(nodeToDel->name, parentNodeToDel->name) < 0){
			parentNodeToDel->left = nodeToDel->left;
		}
		else{
			parentNodeToDel->right = nodeToDel->left;
		}
		free(nodeToDel);
	}
	else if(nodeToDel->left == 0 && nodeToDel->right != 0){
		if(strcmpi(nodeToDel->name, parentNodeToDel->name) > 0){
			parentNodeToDel->left = nodeToDel->right;
		}
		else{
			parentNodeToDel->right = nodeToDel->right;
		}
		free(nodeToDel);
	}
	else{
		struct customer *tp = nodeToDel;
		struct customer *t = nodeToDel->left;
		while(t->right){
			tp = t;
			t = t->right;
		}
		strcpy(nodeToDel->name, t->name);
		strcpy(nodeToDel->membershipName, t->membershipName);
		if(t == tp->right){
			tp->right = 0;
		}
		else{
			tp->left = t->left;
		}
		free(t);
	}
}

//this is needed because if we want to delete root with 1 child, delRecursive will return error.
void delRootCustomer(){
	if(rootCustomer->left == 0 && rootCustomer->right == 0){
		free(rootCustomer);
		rootCustomer = 0;
	}
	else if(rootCustomer->left != 0 && rootCustomer->right == 0){
		struct customer *temp = rootCustomer->left;
		free(rootCustomer);
		rootCustomer = temp;
	}
	else if(rootCustomer->left == 0 && rootCustomer->right != 0){
		struct customer *temp = rootCustomer->right;
		free(rootCustomer);
		rootCustomer = temp;
	}
	else{
		struct customer *tp = rootCustomer;
		struct customer *t = rootCustomer->left;
		while(t->right){
			tp = t;
			t = t->right;
		}
		strcpy(rootCustomer->name, t->name);
		strcpy(rootCustomer->membershipName, t->membershipName);
		if(t == tp->right){
			tp->right = 0;
		}
		else{
			tp->left = t->left;
		}
		free(t);
	}
}

struct customer *parent;
void delCustomer(struct customer *curr, char name[]){
	if(rootCustomer == 0){
		printf("There are no customers!\n");
	}
	//if customer name we want to delete is at the root.
	else if(strcmpi(name, rootCustomer->name) == 0){
		delRootCustomer();
	}
	//if customer name we want to delete is somewhere in BST
	else{
		if(curr == 0){
			printf("Customer not found! Delete cancelled.\n");
			return;
		}
		else if(strcmpi(curr->name, name) == 0){
			//do delete
			delRecursive(parent, curr);
			return;
		}
		else if(strcmpi(name, curr->name) < 0){
			parent = curr;
			delCustomer(curr->left, name);
		}
		else if(strcmpi(name, curr->name) > 0){
			parent = curr;
			delCustomer(curr->right, name);
		}
	}
}

bool isMembershipAvailable(struct membership *curr, char membership[]){
	if(curr == 0){
		return false;
	}
	else if(strcmp(membership, curr->name) == 0){
		return true;
	}
	else if(strcmp(membership, curr->name) < 0){
		isMembershipAvailable(curr->left, membership);
	}
	else if(strcmp(membership, curr->name) > 0){
		isMembershipAvailable(curr->right, membership);
	}
}

void menuInsert(){
	char tempName[cust_name_len];
	char tempMembership[20];
	
	do{
		printf("Enter new customer name: ");
		scanf("%[^\n]", tempName);
		getchar();
	}while(strlen(tempName) < 3 || strlen(tempName) > 50);
	
	do{
		printf("Enter new customer membership: ");
		scanf("%[^\n]", tempMembership);
		getchar();
	}while(!isMembershipAvailable(rootMembership, tempMembership));
	
	insertCustomer(rootCustomer, tempName, tempMembership);
}

void menuDelete(){
	char tempName[cust_name_len];
	
	do{
		printf("Enter new customer name to delete: ");
		scanf("%[^\n]", tempName);
		getchar();
	}while(strlen(tempName) < 3 || strlen(tempName) > 50);
	
	delCustomer(rootCustomer, tempName);
}

int main(){

	insertMembership(rootMembership, "Non-Member");
	insertMembership(rootMembership, "Bronze");
	insertMembership(rootMembership, "Silver");
	insertMembership(rootMembership, "Gold");
	insertMembership(rootMembership, "Platinum");
	
	int menu = 0;
	
	insertCustomer(rootCustomer, "test", "Gold");
	insertCustomer(rootCustomer, "hello", "Gold");
	insertCustomer(rootCustomer, "uto", "Gold");
	
	do{
		system("cls");
		printf("1. Insert customer\n");
		printf("2. View customer\n");
		printf("3. Delete customer\n");
		printf("4. Exit\n");
		do{
			printf("Choose: ");
			scanf("%d", &menu);
			getchar();
		}while(menu < 1 || menu > 4);
		
		switch(menu){
			case 1:
				menuInsert();
				break;
			case 2:
				viewCustomer(rootCustomer);
				getchar();
				break;
			case 3:
				menuDelete();
				break;
		}
	}while(menu != 4);
	
	return 0;
}
